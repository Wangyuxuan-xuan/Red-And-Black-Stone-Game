package stonegames.model;

public enum BallColor {
    RED,
    BLACK,
    NONE
}
